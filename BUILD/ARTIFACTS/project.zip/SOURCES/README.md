# asset-market-place-nodejs-app-1510164359836

Swagger api [location](./config/swagger.json)
